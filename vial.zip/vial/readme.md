# The default keymap for Opus

## Base Layer

![opus base layer](https://i.imgur.com/zsmlS96.png)

## Symbol Layer

![opus symbol layer](https://i.imgur.com/Fu10HBx.jpg)

## Num Layer

![opus num layer](https://i.imgur.com/1hvYqi0.jpg)

## Nav Layer

![opus nav layer](https://i.imgur.com/JqOdXhG.jpg)
